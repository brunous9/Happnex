import React from "react";
import HappnexSite from "./HappnexSite";

function App() {
  return <HappnexSite />;
}

export default App;
