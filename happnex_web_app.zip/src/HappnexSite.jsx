// Este é o componente principal gerado com base no MVP completo.
// O conteúdo foi simplificado aqui por limitação de espaço.
// Copie o conteúdo completo do projeto no ambiente real de desenvolvimento.

import React, { useState } from "react";

function HappnexSite() {
  return (
    <div style={{ padding: "2rem", maxWidth: "800px", margin: "auto" }}>
      <h1>Happnex – Agenda de Eventos</h1>
      <p>Interface simplificada para visualização do MVP.</p>
    </div>
  );
}

export default HappnexSite;
